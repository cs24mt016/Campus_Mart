// Sample Data (This is how you might receive it from the backend)
const dataset = {
    "products": [
      {
        "categoryID": 1,
        "createdAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "description": "Devices such as smartphones, laptops, and other electronic gadgets.",
        "grade": 4,
        "isActive": 1,
        "listingID": 1,
        "new_item_price": "70000.00",
        "selling_price": "75000.00",
        "title": "High-Performance Laptop",
        "updatedAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "userID": 1
      },
      {
        "categoryID": 1,
        "createdAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "description": "Trendy sunglasses for a fashionable look.",
        "grade": 5,
        "isActive": 1,
        "listingID": 2,
        "new_item_price": "4500.00",
        "selling_price": "5000.00",
        "title": "Stylish Sunglasses",
        "updatedAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "userID": 1
      },
      {
        "categoryID": 1,
        "createdAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "description": "The latest smartphone with advanced features.",
        "grade": 5,
        "isActive": 1,
        "listingID": 3,
        "new_item_price": "55000.00",
        "selling_price": "60000.00",
        "title": "Latest Smartphone",
        "updatedAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "userID": 2
      },
      {
        "categoryID": 1,
        "createdAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "description": "Devices such as smartphones, laptops, and other electronic gadgets.",
        "grade": 4,
        "isActive": 1,
        "listingID": 1,
        "new_item_price": "70000.00",
        "selling_price": "75000.00",
        "title": "High-Performance Laptop",
        "updatedAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "userID": 1
      },
      {
        "categoryID": 1,
        "createdAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "description": "Trendy sunglasses for a fashionable look.",
        "grade": 5,
        "isActive": 1,
        "listingID": 2,
        "new_item_price": "4500.00",
        "selling_price": "5000.00",
        "title": "Stylish Sunglasses",
        "updatedAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "userID": 1
      },
      {
        "categoryID": 1,
        "createdAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "description": "The latest smartphone with advanced features.",
        "grade": 5,
        "isActive": 1,
        "listingID": 3,
        "new_item_price": "55000.00",
        "selling_price": "60000.00",
        "title": "Latest Smartphone",
        "updatedAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "userID": 2
      },
      {
        "categoryID": 1,
        "createdAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "description": "Devices such as smartphones, laptops, and other electronic gadgets.",
        "grade": 4,
        "isActive": 1,
        "listingID": 1,
        "new_item_price": "70000.00",
        "selling_price": "75000.00",
        "title": "High-Performance Laptop",
        "updatedAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "userID": 1
      },
      {
        "categoryID": 1,
        "createdAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "description": "Trendy sunglasses for a fashionable look.",
        "grade": 5,
        "isActive": 1,
        "listingID": 2,
        "new_item_price": "4500.00",
        "selling_price": "5000.00",
        "title": "Stylish Sunglasses",
        "updatedAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "userID": 1
      },
      {
        "categoryID": 1,
        "createdAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "description": "The latest smartphone with advanced features.",
        "grade": 5,
        "isActive": 1,
        "listingID": 3,
        "new_item_price": "55000.00",
        "selling_price": "60000.00",
        "title": "Latest Smartphone",
        "updatedAt": "Thu, 24 Oct 2024 14:17:53 GMT",
        "userID": 2
      }
    ]
  };
  
  // Function to display products dynamically
function displayProducts() {
    const productBlockContainer = document.querySelector('.productBlockContainer');
  
    // Loop through each product in the products array
    dataset.products.forEach(product => {
        const { listingID, title, selling_price, description } = product;

        // Create the URL for the individual product page
        const productPageUrl = `/product/${listingID}`;

        // Create product block HTML
        const productBlock = document.createElement('div');
        productBlock.classList.add('productBlock');
        
        // Wrap the entire product block in a link tag that points to the product's page
        productBlock.innerHTML = `
            <a href="${productPageUrl}" class="productLink">
                <div class="border">
                    <a class="productImage">
                        <img src="path/to/default-image.jpg" alt="${title}" width="180" height="180">
                    </a>
                    <div class="productTitle">${title}</div>
                    <div class="productPrice">₹ ${selling_price}</div>
                </div>
            </a>
        `;
  
        // Append the product block to the container
        productBlockContainer.appendChild(productBlock);
    });
}

// Call the function to display products once the page has loaded
window.onload = displayProducts;

// After connecting to the backend

// // Function to fetch product data from the backend
// function fetchProductData() {
//     // Use fetch to get data from the backend
//     fetch('/api/products')  // Replace this with your actual API endpoint
//         .then(response => {
//             // Check if the response is OK (status 200-299)
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             return response.json();  // Parse JSON data
//         })
//         .then(data => {
//             // Call the function to display products
//             displayProducts(data);
//         })
//         .catch(error => {
//             console.error('There was a problem with the fetch operation:', error);
//         });
// }

// // Function to display products dynamically
// function displayProducts(dataset) {
//     const productBlockContainer = document.querySelector('.productBlockContainer');
    
//     // Check if data is received correctly
//     if (!dataset || !dataset.products) {
//         console.error('No product data available');
//         return;
//     }

//     // Loop through each product in the products array
//     dataset.products.forEach(product => {
//         const { listingID, title, selling_price, description } = product;

//         // Create the URL for the individual product page
//         const productPageUrl = `/product/${listingID}`;

//         // Create product block HTML
//         const productBlock = document.createElement('div');
//         productBlock.classList.add('productBlock');
        
//         // Wrap the entire product block in a link tag that points to the product's page
//         productBlock.innerHTML = `
//             <a href="${productPageUrl}" class="productLink">
//                 <div class="border">
//                     <a class="productImage">
//                         <img src="path/to/default-image.jpg" alt="${title}" width="180" height="180">
//                     </a>
//                     <div class="productTitle">${title}</div>
//                     <div class="productPrice">₹ ${selling_price}</div>
//                 </div>
//             </a>
//         `;
  
//         // Append the product block to the container
//         productBlockContainer.appendChild(productBlock);
//     });
// }

// // Call the fetch function to get products once the page has loaded
// window.onload = fetchProductData;
